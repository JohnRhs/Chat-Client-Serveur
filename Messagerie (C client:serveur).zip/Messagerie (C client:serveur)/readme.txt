make pour compiler les deux programmes server et client.
Le serveur se lance avec le port en argument. (ex ./server 8080)
Les clients se connectent avec adresse et port en argument (ex ./client 127.0.0.1 8080)

Normalement toutes les fonctionnalitées sont disponibles sauf le PING que je n'ai pas réussi à faire fonctionner correctement.

Alexandre
Marseloo
22000551
